create
    definer = root@localhost procedure updatenum(IN test_name varchar(64))
BEGIN
    update wordnumber
    set num=(SELECT COUNT(*) FROM wordlist
    WHERE name=test_name);
END;


create view student as
select `shibo`.`user`.`name` AS `name`
from `shibo`.`user`
where (`shibo`.`user`.`is_student` = 'yes');


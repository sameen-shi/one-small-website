create
    definer = root@localhost procedure deny_root(IN test_name varchar(64))
BEGIN 
	IF test_name = 'root' THEN
		SIGNAL SQLSTATE '45001'
			SET MESSAGE_TEXT = "user name can't be root.";
	END IF;
END;


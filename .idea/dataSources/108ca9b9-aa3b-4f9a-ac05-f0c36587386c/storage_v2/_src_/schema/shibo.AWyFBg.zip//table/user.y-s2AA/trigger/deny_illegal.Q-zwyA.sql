create definer = root@localhost trigger deny_illegal
    before INSERT
    on user
    for each row
BEGIN
	CALL deny_root(new.name);
END;

